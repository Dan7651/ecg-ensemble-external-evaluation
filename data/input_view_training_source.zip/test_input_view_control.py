"""Bounded synthetic guards only. No real waveform/checkpoint/model fitting."""
from pathlib import Path
import importlib.util,json,hashlib,random
import numpy as np,torch
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('control',P/'input_view_control.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sp=importlib.util.spec_from_file_location('original_pure',P/'coverage_core.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
torch.set_num_threads(1);checks=[]
x=np.random.default_rng(728).normal(0,.1,(12,5000));assert np.array_equal(m.jepa_view(x),c.preprocess(x)[1]);checks.append('exact_original_transform_parity')
for bad in [np.zeros((8,2500)),np.full((12,5000),np.nan)]:
 try:m.jepa_view(bad);raise AssertionError('accepted bad')
 except ValueError:pass
checks.append('input_shape_finite_guards')
q=np.random.default_rng(20).integers(-1000,1000,(2,8,2500),dtype=np.int32);assert np.array_equal(m.PackedViews(q)[1],q[1].astype(np.float32)/1000.0);checks.append('exact_packed_JEPA_view_accessor')
g=torch.Generator();m.seed_all(19,g);model=m.build_model('resnet');assert model.stem[0].in_channels==8
model.eval()
with torch.inference_mode():assert model(torch.zeros(1,8,2500)).shape==(1,5)
checks.append('full_view_architecture_output_shape')
opt=m.optimizer(model,'resnet');sc=m.scaler_new(torch.device('cpu'),'resnet');xx=torch.randn(2,8,64);yy=torch.randint(0,2,(2,5)).float();m.update(model,opt,sc,xx,yy,'resnet',torch.device('cpu'))
state=dict(model=m.cpu_tree(model.state_dict()),opt=m.cpu_tree(opt.state_dict()),sc=m.cpu_tree(sc.state_dict()),rng=m.cpu_tree(m.rng_state(g)))
x2=torch.randn(2,8,64);y2=torch.randint(0,2,(2,5)).float();m.update(model,opt,sc,x2,y2,'resnet',torch.device('cpu'));expected=m.cpu_tree(dict(model=model.state_dict(),opt=opt.state_dict(),sc=sc.state_dict(),rng=m.rng_state(g)))
replay=m.build_model('resnet');replay.load_state_dict(state['model']);op=m.optimizer(replay,'resnet');op.load_state_dict(state['opt']);sc2=m.scaler_new(torch.device('cpu'),'resnet');sc2.load_state_dict(state['sc']);m.restore_rng(state['rng'],g)
a=torch.randn(2,8,64);b=torch.randint(0,2,(2,5)).float();assert torch.equal(a,x2) and torch.equal(b,y2);m.update(replay,op,sc2,a,b,'resnet',torch.device('cpu'))
assert m.equal(expected,m.cpu_tree(dict(model=replay.state_dict(),opt=op.state_dict(),sc=sc2.state_dict(),rng=m.rng_state(g))));checks.append('synthetic_real_architecture_gradients_optimizer_and_all_CPU_RNG_replay')
h=[dict(epoch=i+1,metrics={'macro_auroc':v}) for i,v in enumerate([.90,.90005,.901,.9009])];assert m.selected_history(h,.0001)==(.901,3,1);checks.append('original_checkpoint_selection_gap')
r=dict(status='passed',checks=checks,synthetic_only=True,real_data_training=False,actual_T4_execution=False,source_sha256=m.sha(P/'input_view_control.py'),protocol_sha256=m.sha(P/'CONTROL_PROTOCOL.json'),test_sha256=m.sha(__file__),torch=torch.__version__,scipy=m.scipy.__version__)
(P/'cpu_sanity_receipt.json').write_text(json.dumps(r,indent=2));print('INPUT_VIEW_BOUNDED_CPU_CHECKS_PASSED',len(checks))
