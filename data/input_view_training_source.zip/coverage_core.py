"""Outcome-free A02/A06 mechanics; no model imports or study reads."""
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy import signal

CLASSES = ['NORM','MI','STTC','CD','HYP']


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()


def coverage_starts(n):
    if not isinstance(n,(int,np.integer)) or n<5000:raise ValueError('At least5000integer samples required')
    return sorted(set(range(0,n-5000+1,5000))|{n-5000})


def population(metadata,mapping):
    targets={int(c):i for i,name in enumerate(CLASSES) for c in mapping['groups'][name]}
    records=[];seen=set()
    with Path(metadata).open(newline='',encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            rid=row['ECG_ID'];assert rid not in seen;seen.add(rid)
            codes=[int(t.split('+')[0]) for t in row['AHA_Code'].split(';')]
            assert not (1 in codes and any(c!=1 for c in codes))
            n=int(row['N']);assert n>=5000
            y=[int(any(targets.get(c)==i for c in codes)) for i in range(5)]
            records.append(dict(id=rid,patient_id=row['Patient_ID'],samples=n,labels=y,selected=bool(any(y))))
    return records


def tasks_for(records):
    tasks=[]
    for row in records:
        if not row['selected']:tasks.append(dict(**row,analysis='A02',start=0))
    for row in records:
        if row['selected'] and row['samples']>5000:
            for start in coverage_starts(row['samples'])[1:]:tasks.append(dict(**row,analysis='A06',start=start))
    return tasks


def preprocess(x):
    x=np.asarray(x,dtype=np.float64)
    if x.shape!=(12,5000) or not np.isfinite(x).all():raise ValueError('Unknown waveform shape/values')
    sos=signal.butter(4,[.5/50,40/50],btype='band',output='sos')
    low=signal.sosfiltfilt(sos,signal.resample_poly(x,1,5,axis=1),axis=1).astype(np.float32)
    eight=signal.resample(x[[0,1,6,7,8,9,10,11]],2500,axis=1)
    eight=np.rint(eight*1000).astype(np.int32).astype(np.float32)/1000
    assert low.shape==(12,1000) and eight.shape==(8,2500) and np.isfinite(low).all() and np.isfinite(eight).all()
    return low,eight


def mean_with_saved_first(first,extra):
    first=np.asarray(first);extra=np.asarray(extra)
    if first.dtype!=np.float32 or extra.dtype!=np.float32 or first.shape!=(5,) or extra.ndim!=2 or extra.shape[1]!=5:
        raise ValueError('Expected FP32 five-class probability arrays')
    return np.concatenate([first[None],extra]).mean(0,dtype=np.float32)


def strict_interval(values,minimum=1960):
    v=np.asarray(values,float);good=v[np.isfinite(v)]
    if len(good)<minimum:return dict(valid=len(good),interval=None,reason='insufficient valid patient draws')
    return dict(valid=len(good),interval=np.percentile(good,[2.5,97.5]).tolist(),percentiles=[2.5,97.5])


def clean(value):
    if isinstance(value,dict):return {k:clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [clean(v) for v in value]
    if isinstance(value,np.ndarray):return clean(value.tolist())
    if isinstance(value,(float,np.floating)):return float(value) if np.isfinite(value) else None
    if isinstance(value,np.integer):return int(value)
    return value
