"""Additional post hoc supervised ResNet on exact JEPA input: fitting only.

Entry on a Colab T4 after validating the independently deposited protocol.
Original architecture classes are extracted from the pinned source AST, never
by importing the original script with its mount/training side effects.
"""
from __future__ import annotations
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import argparse
import ast
import copy
from datetime import datetime, timezone
import fcntl
import hashlib
import json
from pathlib import Path
import platform
import random
import sys
import time

import numpy as np
import scipy
import sklearn
from sklearn.metrics import average_precision_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

HERE = Path(__file__).resolve().parent
SEEDS = (101, 202, 303, 404, 505)
FAMILIES = ('resnet', 'jepa_head')
BASE = Path('/content/drive/MyDrive')
CACHE = BASE / 'ECG_Diagnosis_Project/processed_cache/ptbxl_jepa_250hz_v1'
RESULTS = BASE / 'ECG_Project_Final_Results'
FEATURES = RESULTS / 'jepa_external_frozen_dev8_seed42'
OUT = RESULTS / 'sph_resnet_jepa_view_five_seed_20261028_v1'
LOCAL = Path('/content/sph_resnet_jepa_view_cache_v1')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''): h.update(block)
    return h.hexdigest()


def json_read(path): return json.loads(Path(path).read_text())


def atomic(path, value, kind='json', immutable=False):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if kind == 'json':
        data = (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
        if path.exists() and immutable:
            if path.read_bytes() != data: raise RuntimeError('Immutable artifact changed: ' + str(path))
            return
    elif immutable and path.exists(): raise RuntimeError('Existing immutable binary: ' + str(path))
    tmp = path.with_name(path.name + '.partial')
    with tmp.open('wb') as f:
        if kind == 'torch': torch.save(value, f)
        elif kind == 'npz': np.savez_compressed(f, **value)
        else: f.write(data)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def cpu_tree(value):
    if torch.is_tensor(value): return value.detach().cpu().clone()
    if isinstance(value, dict): return {k: cpu_tree(v) for k, v in value.items()}
    if isinstance(value, list): return [cpu_tree(v) for v in value]
    if isinstance(value, tuple): return tuple(cpu_tree(v) for v in value)
    if isinstance(value, np.ndarray): return value.copy()
    return copy.deepcopy(value)


def equal(a, b):
    if torch.is_tensor(a): return torch.equal(a, b)
    if isinstance(a, np.ndarray): return np.array_equal(a, b)
    if isinstance(a, dict): return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)): return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def seed_all(seed, generator):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    generator.manual_seed(seed)


def rng_state(generator):
    return dict(python=random.getstate(), numpy=np.random.get_state(), cpu=torch.get_rng_state(),
                cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [], shuffle=generator.get_state())


def restore_rng(state, generator):
    random.setstate(state['python']); np.random.set_state(state['numpy']); torch.set_rng_state(state['cpu'])
    if state['cuda']: torch.cuda.set_rng_state_all(state['cuda'])
    generator.set_state(state['shuffle'])


def selected_history(history, minimum_improvement):
    best, selected, stale = -1., 0, 0
    for row in history:
        if row['metrics']['macro_auroc'] > best + minimum_improvement:
            best, selected, stale = row['metrics']['macro_auroc'], row['epoch'], 0
        else: stale += 1
    return best, selected, stale


def architecture_nodes(source):
    nodes = [n for n in ast.parse(source).body if isinstance(n, ast.ClassDef)
             and n.name in {'ResidualBlock', 'OriginalResNet'}]
    assert [n.name for n in nodes] == ['ResidualBlock', 'OriginalResNet']
    return nodes


def build_model(family):
    if family!='resnet':raise ValueError(family)
    path=HERE/'multiscale_waveform_dev8.py'
    assert sha(path)=='79bb48ea71a033f21dfd734c5fbc4fbb3dc0823be4c2cdd2137f47b5494bc44e'
    nodes=architecture_nodes(path.read_text())
    node=next(n for n in nodes if n.name=='OriginalResNet')
    count=0
    for n in ast.walk(node):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='Conv1d' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value==12:
            n.args[0]=ast.Constant(8);count+=1
    assert count==1,'Only stem input channel count may change'
    ns={'torch':torch,'nn':nn};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(path),'exec'),ns)
    return ns['OriginalResNet']()



def optimizer(model, family):
    return torch.optim.AdamW(model.parameters(), lr=.001 if family == 'resnet' else .0003, weight_decay=.01)


def scaler_new(device, family):
    if device.type == 'cpu':
        # Bounded local guards also run on older CPU-only Torch. T4 uses the
        # same modern CUDA GradScaler as the original recipe below.
        return torch.cuda.amp.GradScaler(enabled=False)
    return torch.amp.GradScaler('cuda', enabled=(device.type == 'cuda' and family == 'resnet'))


def update(model, opt, scaler, x, y, family, device):
    model.train(); opt.zero_grad(set_to_none=True)
    with torch.autocast(device.type, dtype=torch.float16, enabled=(device.type == 'cuda' and family == 'resnet')):
        loss = nn.functional.binary_cross_entropy_with_logits(model(x.to(device)), y.to(device))
    if not torch.isfinite(loss): raise FloatingPointError('Nonfinite loss')
    scaler.scale(loss).backward(); scaler.unscale_(opt)
    if any(p.grad is None or not torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad):
        raise FloatingPointError('Missing/nonfinite trainable gradient')
    if family == 'resnet':
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
        if not torch.isfinite(norm): raise FloatingPointError('Nonfinite clipped gradients')
    scaler.step(opt); scaler.update()
    return float(loss.detach())


def copy_cached(source, target, expected):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and sha(target) == expected: return
    if target.exists():
        preserved = target.with_name(target.name + '.unverified_' + sha(target)[:12])
        if preserved.exists(): raise RuntimeError('Repeated cache corruption')
        target.rename(preserved)
    tmp = target.with_name(target.name + '.partial'); digest = hashlib.sha256()
    with source.open('rb') as a, tmp.open('wb') as b:
        for block in iter(lambda: a.read(4 * 1024 * 1024), b''):
            digest.update(block); b.write(block)
        b.flush(); os.fsync(b.fileno())
    assert digest.hexdigest() == expected, 'Pinned existing cache hash failed'
    assert sha(tmp) == expected, 'Local cache persistence failed'
    os.replace(tmp, target)


class WaveRows(Dataset):
    def __init__(self, signals, rows, labels, mean, std):
        self.signals, self.rows, self.labels, self.mean, self.std = signals, rows, labels, mean, std
    def __len__(self): return len(self.rows)
    def __getitem__(self, index):
        row = int(self.rows[index])
        return torch.from_numpy(((self.signals[row] - self.mean) / self.std).astype(np.float32)), torch.from_numpy(self.labels[row].copy())


def data_prepare():
    # Reuse EXACT packed inputs used for the original JEPA feature extraction.
    # Rebuilding from FP32 500Hz cache could perturb 1uV rounding boundaries.
    manifest=json_read(HERE/'jepa_input_transfer_manifest.json')
    assert manifest['packed_sha256']=='5bc139bcc9b50cd5fa8bb97164441d084d1fade200cd8ae886aebb26ead5bf79'
    assert manifest['source_waveform_sha256']=='8bddf41d182f700f69dca97c81f662dcc3b3670d0b79a19bdc3ec90e7729067e'
    packed=CACHE/manifest['packed_filename'];copy_cached(packed,LOCAL/packed.name,manifest['packed_sha256'])
    meta=BASE/'ECG_Diagnosis_Project/processed_cache/ptb-xl_amplitude_v1/labels_and_folds.npz'
    assert sha(meta)=='79f69a27dcfc4aab024a8154ed32966bf6d2d1dfa18773e2f1090350bad9d5d7'
    with np.load(meta,allow_pickle=False) as z:ids,patients,folds,y=[z[k].copy() for k in ['ecg_id','patient_id','strat_fold','y_standard']]
    y=y.astype(np.float32);assert y.shape==(21799,5) and np.isin(y,[0,1]).all()
    tr=np.flatnonzero(np.isin(folds,range(1,8))&(y.sum(1)>0));va=np.flatnonzero((folds==8)&(y.sum(1)>0));assert (len(tr),len(va))==(14955,2129)
    assert not set(patients[tr]).intersection(patients[va])
    with np.load(LOCAL/packed.name,allow_pickle=False) as z:wave=z['signal_q_mv']
    assert wave.shape==(21799,8,2500) and wave.dtype==np.int32
    view=PackedViews(wave)
    for k in tr[:64]:assert np.array_equal(view[k],wave[k].astype(np.float32)/1000.0)
    identity=hashlib.sha256(ids[np.r_[tr,va]].tobytes()+y[np.r_[tr,va]].tobytes()+patients[np.r_[tr,va]].tobytes()).hexdigest()
    atomic(OUT/'input_identity_receipt.json',dict(packed_sha256=manifest['packed_sha256'],metadata_sha256=sha(meta),original_feature_input_reused_exactly=True,source_sha256=sha(__file__),no_new_preprocessing=True,train_records=len(tr),development_records=len(va)),immutable=True)
    return dict(y=y,ids=ids,patients=patients,tr=tr,va=va,signals=view,mean=np.zeros((8,1),np.float32),std=np.ones((8,1),np.float32),data_identity_sha256=identity)




@torch.inference_mode()
def predict(model, family, data, device):
    model.eval(); parts = []
    if family == 'resnet':
        dataset = WaveRows(data['signals'], data['va'], data['y'], data['mean'], data['std'])
        batches = (x for x, _ in DataLoader(dataset, batch_size=128, shuffle=False, num_workers=0))
    else:
        batches = [torch.from_numpy(data['xv'])]  # exact original full development head forward
    for x in batches:
        with torch.autocast(device.type, dtype=torch.float16, enabled=(family == 'resnet' and device.type == 'cuda')):
            logits = model(x.to(device))
        parts.append(logits.float().sigmoid().cpu().numpy())
    p = np.concatenate(parts)
    assert p.shape == (2129, 5) and p.dtype == np.float32 and np.isfinite(p).all()
    return p


def metrics(y, p):
    return dict(macro_auroc=float(roc_auc_score(y, p, average='macro')),
                macro_ap=float(average_precision_score(y, p, average='macro')),
                macro_f1_at_0_5=float(f1_score(y, p >= .5, average='macro', zero_division=0)))


def actual_preflight(family, data, device, global_sha, boot):
    receipt_path = OUT / f'preflight_{family}_{boot}.json'
    if receipt_path.exists():
        r = json_read(receipt_path); assert r['passed'] and r['global_protocol_sha256'] == global_sha; return
    g = torch.Generator(); seed_all(8101, g)
    m = build_model(family).to(device); o = optimizer(m, family); sc = scaler_new(device, family)
    width = (8, 2500) if family == 'resnet' else (768,)
    x = torch.randn((4,) + width); y = torch.randint(0, 2, (4, 5)).float()
    update(m, o, sc, x, y, family, device)
    state = dict(model=cpu_tree(m.state_dict()), opt=cpu_tree(o.state_dict()), scaler=cpu_tree(sc.state_dict()), rng=cpu_tree(rng_state(g)))
    x2 = torch.randn((4,) + width); y2 = torch.randint(0, 2, (4, 5)).float()
    update(m, o, sc, x2, y2, family, device)
    expected = dict(model=cpu_tree(m.state_dict()), opt=cpu_tree(o.state_dict()), scaler=cpu_tree(sc.state_dict()), rng=cpu_tree(rng_state(g)))
    del m, o, sc; torch.cuda.empty_cache()
    replay = build_model(family).to(device); replay.load_state_dict(state['model'], strict=True)
    o = optimizer(replay, family); o.load_state_dict(state['opt']); sc = scaler_new(device, family); sc.load_state_dict(state['scaler'])
    restore_rng(state['rng'], g)
    xx = torch.randn((4,) + width); yy = torch.randint(0, 2, (4, 5)).float()
    assert torch.equal(xx, x2) and torch.equal(yy, y2)
    update(replay, o, sc, xx, yy, family, device)
    observed = dict(model=cpu_tree(replay.state_dict()), opt=cpu_tree(o.state_dict()), scaler=cpu_tree(sc.state_dict()), rng=cpu_tree(rng_state(g)))
    assert equal(expected, observed), 'Actual model/optimizer/scaler/all-RNG continuation failed'
    del replay, o, sc, state, expected, observed; torch.cuda.empty_cache()
    seed_all(8102, g); m = build_model(family).to(device); o = optimizer(m, family); sc = scaler_new(device, family)
    if family == 'resnet':
        dataset = WaveRows(data['signals'], data['tr'][:64], data['y'], data['mean'], data['std'])
        x, y = next(iter(DataLoader(dataset, batch_size=64, num_workers=0)))
    else:
        x, y = torch.from_numpy(data['xt'][:64]), torch.from_numpy(data['y'][data['tr'][:64]])
    for _ in range(2): update(m, o, sc, x, y, family, device)
    torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats(); tick = time.monotonic()
    for _ in range(4): update(m, o, sc, x, y, family, device)
    torch.cuda.synchronize(); seconds = time.monotonic() - tick
    peak = max(torch.cuda.max_memory_allocated(), torch.cuda.max_memory_reserved()) / 2**30
    estimate = seconds / 4 * ((14955 + 63) // 64) / 60 if family == 'resnet' else None
    passed = peak <= 14 and (estimate is None or estimate <= 10)
    r = dict(passed=bool(passed), family=family, boot_id=boot, global_protocol_sha256=global_sha,
             actual_synthetic_model_optimizer_scaler_all_rng_exact_replay=True, finite_gradients=True,
             unique_training_records=64, warmup_updates=2, measured_updates=4, measured_seconds=seconds,
             peak_gib=peak, estimated_resnet_training_minutes_per_epoch=estimate,
             disposable_updates_discarded=True, no_development_used_for_capacity=True)
    atomic(receipt_path, r, immutable=True)
    del m, o, sc, x, y; torch.cuda.empty_cache()
    assert passed, 'Fixed capacity gate failed; do not relax protocol'
    print('INPUT_VIEW_REAL_T4_PREFLIGHT_PASSED ' + json.dumps(r), flush=True)


def load_commit(folder, protocol_sha, family):
    choices = []
    for slot in (0, 1):
        path = folder / f'last_{slot}.pth'; receipt = path.with_suffix('.receipt.json')
        if not path.exists() or not receipt.exists(): continue
        info = json_read(receipt)
        if sha(path) != info['sha256']: continue  # preserve corrupt/incomplete generation; try the other.
        s = torch.load(path, map_location='cpu', weights_only=False)
        assert s['protocol_sha256'] == protocol_sha and s['family'] == family
        assert info['protocol_sha256'] == protocol_sha
        assert s['epoch'] == info['epoch'] and len(s['history']) == s['epoch']
        gap = .0001 if family == 'resnet' else .000001
        assert selected_history(s['history'], gap) == (s['best_auc'], s['selected_epoch'], s['stale'])
        assert s['updates'] == s['epoch'] * ((14955 + (63 if family == 'resnet' else 255)) // (64 if family == 'resnet' else 256))
        choices.append(s)
    if not choices:
        if list(folder.glob('last_*')): raise RuntimeError('No complete recoverable checkpoint; preserve evidence')
        return None
    return max(choices, key=lambda s: s['epoch'])


def verify_endpoint(folder, global_sha, family, seed):
    protocol_path = folder / 'protocol.json'; protocol = json_read(protocol_path)
    assert protocol['global_protocol_sha256'] == global_sha
    assert protocol['family'] == family and protocol['seed'] == seed
    assert protocol['source_sha256'] == sha(__file__)
    e = json_read(folder / 'endpoint.json')
    assert e['protocol_sha256'] == sha(protocol_path)
    assert e['family'] == family and e['seed'] == seed and e['source_sha256'] == sha(__file__)
    assert e['exact_fresh_saved_best_replay'] and e['no_external_inference'] and e['no_fold9_or_10_prediction']
    assert sha(folder / 'best_model.pth') == e['checkpoint_sha256']
    assert sha(folder / 'development_predictions.npz') == e['prediction_sha256']
    history = json_read(folder / 'history.json')
    assert len(history) == e['completed_epochs']
    best, selected, stale = selected_history(history, protocol['selection_gap'])
    assert selected == e['selected_epoch'] and best == e['development_metrics']['macro_auroc']
    assert e['completed_epochs'] == protocol['max_epochs'] or stale >= protocol['patience']
    assert e['updates'] == history[-1]['updates'] == len(history) * ((14955 + protocol['batch'] - 1) // protocol['batch'])
    return e


def fit(family, seed, data, global_sha, device):
    folder = OUT / family / f'seed{seed}'; folder.mkdir(parents=True, exist_ok=True)
    protocol = dict(global_protocol_sha256=global_sha, family=family, seed=seed,
                    train_folds=list(range(1, 8)), development_fold=8, train_records=14955,
                    development_records=2129, selection_gap=.0001 if family == 'resnet' else .000001,
                    max_epochs=20 if family == 'resnet' else 40, patience=6 if family == 'resnet' else 8,
                    batch=64 if family == 'resnet' else 256, drop_last=False,
                    data_identity_sha256=data['data_identity_sha256'], source_sha256=sha(__file__))
    atomic(folder / 'protocol.json', protocol, immutable=True); protocol_sha = sha(folder / 'protocol.json')
    if (folder / 'endpoint.json').exists():
        e = verify_endpoint(folder, global_sha, family, seed)
        print('INPUT_VIEW_COMPLETED_FIT_REUSED', family, seed, flush=True); return e
    g = torch.Generator(); seed_all(seed, g); model = build_model(family).to(device)
    opt = optimizer(model, family); sc = scaler_new(device, family)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=20, eta_min=1e-5) if family == 'resnet' else None
    epoch, best_auc, selected, stale, history, best, updates = 0, -1., 0, 0, [], None, 0
    if family == 'resnet':
        dataset = WaveRows(data['signals'], data['tr'], data['y'], data['mean'], data['std'])
        loader = DataLoader(dataset, batch_size=64, shuffle=True, generator=g, num_workers=0, drop_last=False)
    else:
        tx, ty = torch.from_numpy(data['xt']).to(device), torch.from_numpy(data['y'][data['tr']]).to(device)
    s = load_commit(folder, protocol_sha, family)
    if s:
        assert s['seed'] == seed
        model.load_state_dict(s['model']); opt.load_state_dict(s['optimizer']); sc.load_state_dict(s['scaler'])
        if sched is not None: sched.load_state_dict(s['scheduler'])
        epoch, best_auc, selected, stale, history, best, updates = (s[k] for k in ['epoch', 'best_auc', 'selected_epoch', 'stale', 'history', 'best_model', 'updates'])
        restore_rng(s['rng'], g)
        print('INPUT_VIEW_RESUME_AFTER_COMPLETE_EPOCH', family, seed, epoch, flush=True)
    while epoch < protocol['max_epochs'] and stale < protocol['patience']:
        tick = time.monotonic(); total = 0.; used = 0; rate = float(opt.param_groups[0]['lr'])
        if family == 'resnet': batches = loader
        else:
            order = torch.randperm(len(tx), device=device)
            batches = ((tx[order[i:i+256]], ty[order[i:i+256]]) for i in range(0, len(tx), 256))
        for x, y in batches:
            total += update(model, opt, sc, x, y, family, device) * len(x); used += len(x); updates += 1
        assert used == 14955
        p = predict(model, family, data, device); point = metrics(data['y'][data['va']], p)
        epoch += 1
        if sched is not None: sched.step()
        if point['macro_auroc'] > best_auc + protocol['selection_gap']:
            best_auc, selected, stale, best = point['macro_auroc'], epoch, 0, cpu_tree(model.state_dict())
        else: stale += 1
        history.append(dict(epoch=epoch, train_bce=total/used, metrics=point, updates=updates,
                            learning_rate_used=rate, seconds=time.monotonic()-tick))
        s = dict(protocol_sha256=protocol_sha, family=family, seed=seed, epoch=epoch,
                 model=cpu_tree(model.state_dict()), optimizer=cpu_tree(opt.state_dict()), scaler=cpu_tree(sc.state_dict()),
                 scheduler=cpu_tree(sched.state_dict()) if sched is not None else None,
                 rng=cpu_tree(rng_state(g)), best_auc=best_auc, selected_epoch=selected, stale=stale,
                 best_model=cpu_tree(best), history=copy.deepcopy(history), updates=updates)
        target = folder / f'last_{epoch % 2}.pth'; atomic(target, s, 'torch')
        digest = sha(target)
        atomic(target.with_suffix('.receipt.json'), dict(epoch=epoch, sha256=digest, protocol_sha256=protocol_sha))
        assert sha(target) == digest
        atomic(folder / 'history.json', history)
        atomic(OUT / 'status.json', dict(phase='training', family=family, seed=seed, completed_epoch=epoch,
               selected_epoch=selected, updates=updates, updated_utc=datetime.now(timezone.utc).isoformat()))
        print('INPUT_VIEW_EPOCH ' + json.dumps(dict(family=family, seed=seed, selected_epoch=selected, **history[-1])), flush=True)
    assert best is not None and selected_history(history, protocol['selection_gap']) == (best_auc, selected, stale)
    # A crash may have occurred between checkpoint commit and the redundant
    # readable history export. Restore that export even if early stopping has
    # already completed; this never performs another optimizer update.
    atomic(folder / 'history.json', history)
    model.load_state_dict(best); p = predict(model, family, data, device)
    del model, opt, sc, sched; torch.cuda.empty_cache()
    checkpoint = dict(model=best, protocol=protocol, selected_epoch=selected, epoch_history=history)
    atomic(folder / 'best_model.pth', checkpoint, 'torch')
    replay_model = build_model(family).to(device)
    exported = torch.load(folder / 'best_model.pth', map_location='cpu', weights_only=False)
    replay_model.load_state_dict(exported['model'], strict=True)
    replay = predict(replay_model, family, data, device)
    assert np.array_equal(p, replay), 'Fresh saved-best prediction replay failed'
    atomic(folder / 'development_predictions.npz', dict(ecg_id=data['ids'][data['va']], patient_id=data['patients'][data['va']],
           y_true=data['y'][data['va']], y_prob=p), 'npz')
    e = dict(family=family, seed=seed, protocol_sha256=protocol_sha, completed_epochs=epoch,
             selected_epoch=selected, updates=updates, development_metrics=metrics(data['y'][data['va']], p),
             checkpoint_sha256=sha(folder / 'best_model.pth'), prediction_sha256=sha(folder / 'development_predictions.npz'),
             exact_fresh_saved_best_replay=True, source_sha256=sha(__file__), no_external_inference=True,
             no_fold9_or_10_prediction=True, checkpoint_persistence_after_remount_verified=False)
    atomic(folder / 'endpoint.json', e, immutable=True)
    del replay_model; torch.cuda.empty_cache()
    print('INPUT_VIEW_FIT_COMPLETED ' + json.dumps(e), flush=True)
    return e


def main():
    if sys.flags.optimize:raise RuntimeError('Assertions must remain enabled')
    ap=argparse.ArgumentParser();ap.add_argument('--fit',action='store_true');args=ap.parse_args()
    assert torch.cuda.is_available() and 'T4' in torch.cuda.get_device_name(0),'Use existing preauthorized T4'
    assert CACHE.is_dir(),'Existing Drive cache required; no redownload'
    lock=open('/content/sph_input_view_control_v1.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    OUT.mkdir(exist_ok=True);LOCAL.mkdir(exist_ok=True)
    torch.backends.cudnn.benchmark=False;torch.use_deterministic_algorithms(True);torch.set_num_threads(2)
    env=dict(python=platform.python_version(),torch=torch.__version__,cuda=torch.version.cuda,cudnn=torch.backends.cudnn.version(),numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,gpu=torch.cuda.get_device_name(0),deterministic=True)
    atomic(OUT/'environment.json',env,immutable=True)
    plan=json_read(HERE/'CONTROL_PROTOCOL.json');assert plan['seeds']==list(SEEDS)
    protocol=dict(scope='additional post hoc input-view control, not original deposited A01',seeds=list(SEEDS),source_sha256=sha(__file__),protocol_file_sha256=sha(HERE/'CONTROL_PROTOCOL.json'),architecture_source_sha256=sha(HERE/'multiscale_waveform_dev8.py'),environment_sha256=sha(OUT/'environment.json'),transform='exact existing original JEPA packed feature-input array; int32 to FP32 /1000',no_external_inference=True,no_fold9_or10_access=True)
    atomic(OUT/'training_protocol.json',protocol,immutable=True);global_sha=sha(OUT/'training_protocol.json')
    if (OUT/'all_five_fits_locked.json').exists():
        e=[verify_endpoint(OUT/'resnet'/f'seed{seed}',global_sha,'resnet',seed) for seed in SEEDS];assert equal(e,json_read(OUT/'all_five_fits_locked.json')['endpoints']);print('INPUT_VIEW_ALL_FIVE_REUSED');return
    data=data_prepare();boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    actual_preflight('resnet',data,torch.device('cuda'),global_sha,boot)
    print('INPUT_VIEW_T4_PREFLIGHT_PASSED',flush=True)
    if not args.fit:return
    endpoints=[fit('resnet',seed,data,global_sha,torch.device('cuda')) for seed in SEEDS]
    atomic(OUT/'all_five_fits_locked.json',dict(global_protocol_sha256=global_sha,endpoints=endpoints,no_external_inference=True),immutable=True)
    atomic(OUT/'status.json',dict(phase='five_fits_complete_awaiting_persistence_and_locked_inference',no_external_inference=True))
    print('INPUT_VIEW_ALL_FIVE_COMPLETE_NO_EXTERNAL_INFERENCE',flush=True)




def jepa_view(x):
    from scipy.signal import resample
    x=np.asarray(x,dtype=np.float64)
    if x.shape!=(12,5000) or not np.isfinite(x).all():raise ValueError('Require finite12x5000 physicalmV')
    q=resample(x[[0,1,6,7,8,9,10,11]],2500,axis=1)
    q=np.rint(q*1000).astype(np.int32).astype(np.float32)/1000
    assert q.shape==(8,2500) and q.dtype==np.float32 and np.isfinite(q).all()
    return q

class PackedViews:
    def __init__(self,wave):self.wave=wave
    def __getitem__(self,row):return self.wave[int(row)].astype(np.float32)/1000.0


if __name__ == '__main__': main()
