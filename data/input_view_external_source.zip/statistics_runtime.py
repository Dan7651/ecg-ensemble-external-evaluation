"""Fixed saved-score comparisons with resumable paired patient resampling."""
import time
from input_view_followup_common import *
from sph_component_statistics_v1 import ScoreStatistics
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score

COLS = [0, 1, 2, 6]
GROUPS = ['original_RR', 'JJ', 'original_RJ', 'view_RR', 'view_RJ']

def definitions():
    pairs = []
    for group in GROUPS:
        for i in range(5):
            j = (i + 1) % 5
            a = i if group.startswith('original') else (10+i if group == 'JJ' else 5+i)
            b = (j if group == 'original_RR' else 5+j if group == 'view_RR' else 10+j)
            pairs.append((group, i, j, a, b))
    return pairs

def gains(points):
    values = []
    for k, (_, _, _, a, b) in enumerate(definitions()):
        g = points[15+k] - np.maximum(points[a], points[b])
        g[3] = min(points[a, 3], points[b, 3]) - points[15+k, 3]
        values.append(g)
    return np.asarray(values).reshape(5, 5, 4)

def contrasts(points):
    g = gains(points).mean(1)
    return np.stack([g[4]-g[2], g[4]-g[3], g[4]-g[1], (points[5:10]-points[:5]).mean(0)])

def reference(y, scores, weights=None):
    return np.asarray([roc_auc_score(y, scores, average='macro', sample_weight=weights),
        average_precision_score(y, scores, average='macro', sample_weight=weights),
        f1_score(y, scores >= .5, average='macro', sample_weight=weights, zero_division=0),
        np.average((scores.astype(np.float64)-y)**2, axis=0, weights=weights).mean()])

def interval(draws):
    valid = np.all(np.isfinite(draws), axis=tuple(range(1, draws.ndim)))
    n = int(valid.sum())
    return dict(valid=n, ci95=np.percentile(draws[valid], [2.5, 97.5], axis=0).tolist() if n >= 1960 else None,
                interpretation='Conditional patient percentile interval; historically viewed cohort; seed pairs overlap')

def run_statistics():
    plan = read(HERE / 'EVALUATION_PLAN.json'); lock_sha = sha(OUT / 'inference_lock.json')
    lock = read(OUT / 'inference_lock.json'); assert lock['plan_sha256'] == sha(HERE / 'EVALUATION_PLAN.json')
    completed = OUT / 'assessment.json'
    if completed.exists():
        e = read(completed)
        assert e['inference_lock_sha256'] == lock_sha and e['statistics_source_sha256'] == sha(__file__)
        assert sha(OUT / 'patient_bootstrap_draws.npz') == e['draws_sha256']
        print('INPUT_VIEW_EXISTING_ASSESSMENT_REUSED', flush=True); return
    manifest = read(OUT / 'prediction_manifest.json'); assert manifest['inference_lock_sha256'] == lock_sha
    assert len(manifest['parts']) == 83
    arrays = {key: [] for key in ['ids', 'patient_id', 'y', 'view_resnet', 'original_resnet', 'jepa']}
    for part in manifest['parts']:
        path = OUT / 'prediction_chunks' / part['filename']; assert sha(path) == part['sha256']
        with np.load(path, allow_pickle=False) as z:
            assert str(z['inference_lock_sha256']) == lock_sha
            for key in arrays: arrays[key].append(z[key].copy())
    data = {k: np.concatenate(v, axis=1 if k in ['view_resnet', 'original_resnet', 'jepa'] else 0) for k, v in arrays.items()}
    y = data['y']; patients = data['patient_id']
    assert y.shape == (21183, 5) and y.sum(0).tolist() == plan['positive_counts']
    assert len(set(data['ids'].tolist())) == 21183 and len(set(patients.tolist())) == 20401
    singles = list(data['original_resnet']) + list(data['view_resnet']) + list(data['jepa'])
    scores = singles + [(singles[a]+singles[b])*.5 for _, _, _, a, b in definitions()]
    stats = [ScoreStatistics(y, score) for score in scores]
    point = np.asarray([s.evaluate()['macro'][COLS] for s in stats])
    for score, row in zip(scores, point): np.testing.assert_allclose(row, reference(y, score), atol=1e-12, rtol=0)
    unique, inv = np.unique(patients, return_inverse=True); n = len(unique)
    rng = np.random.default_rng(plan['bootstrap']['seed']); draws = np.full((2000, 40, 4), np.nan)
    start = 0; checked = []; max_error = 0.
    recovered = recover_bootstrap(OUT, lock_sha)
    if recovered:
        meta, chunk = recovered
        start = meta['completed']; draws[:start] = chunk; rng.bit_generator.state = meta['rng']
        checked = meta['expanded_checked']; max_error = meta['expanded_max_error']
    tick = time.monotonic()
    for b in range(start, 2000):
        w = np.bincount(rng.integers(n, size=n), minlength=n)[inv]
        draws[b] = np.asarray([s.evaluate(w)['macro'][COLS] for s in stats])
        if b in [0, 1999]:
            expanded = np.repeat(np.arange(len(y)), w)
            for score, row in zip(scores, draws[b]):
                ref = reference(y[expanded], score[expanded])
                max_error = max(max_error, float(np.max(np.abs(row-ref))))
                np.testing.assert_allclose(row, ref, atol=1e-12, rtol=0)
            checked.append(b)
        if (b+1) % 50 == 0:
            meta = dict(completed=b+1, inference_lock_sha256=lock_sha, rng=rng.bit_generator.state,
                        expanded_checked=checked, expanded_max_error=max_error)
            save_bootstrap(OUT, draws[:b+1], meta)
            atomic(OUT / 'status.json', dict(phase='paired_patient_bootstrap', completed_draws=b+1, planned_draws=2000))
            print('INPUT_VIEW_PATIENT_DRAWS', b+1, 2000, flush=True)
    contrast_draws = np.asarray([contrasts(d) for d in draws])
    atomic(OUT / 'patient_bootstrap_draws.npz', dict(macro=draws, contrasts=contrast_draws), binary=True)
    def summary(values):
        return dict(mean=values.mean(0).tolist(), sample_sd=values.std(0, ddof=1).tolist(),
                    minimum=values.min(0).tolist(), maximum=values.max(0).tolist())
    result = dict(status='INPUT_VIEW_EXTERNAL_ASSESSMENT_COMPLETED_REQUIRES_INDEPENDENT_VERIFICATION',
        inference_lock_sha256=lock_sha, statistics_source_sha256=sha(__file__), records=21183, patients=20401,
        seeds=SEEDS, metrics=plan['metrics'], single_order=['original_resnet','view_resnet','jepa'],
        singles=point[:15].reshape(3,5,4).tolist(), single_summary={k:summary(point[i*5:(i+1)*5]) for i,k in enumerate(['original_resnet','view_resnet','jepa'])},
        pair_definitions=definitions(), pair_order=GROUPS, pair_metrics=point[15:].reshape(5,5,4).tolist(),
        gains_over_better_component=gains(point).tolist(), gain_summary={k:summary(gains(point)[i]) for i,k in enumerate(GROUPS)},
        contrast_order=['view_RJ_gain_minus_original_RJ_gain','view_RJ_gain_minus_view_RR_gain','view_RJ_gain_minus_JJ_gain','view_R_minus_original_R_metric'],
        contrasts=contrasts(point).tolist(), conditional_patient_intervals=interval(contrast_draws),
        per_class_metrics=[s.evaluate()['per_class'].tolist() for s in stats],
        per_class_metric_order=['auroc','ap','f1','precision','recall','specificity','brier'],
        draws_sha256=sha(OUT / 'patient_bootstrap_draws.npz'), draws=2000, bootstrap_seed=plan['bootstrap']['seed'],
        literal_expanded_draws_checked=checked, maximum_expanded_error=max_error,
        bootstrap_seconds_this_execution=time.monotonic()-tick,
        limits=plan['restrictions']+[plan['interpretation'], 'Intervals condition on these fitted models and are not selection adjusted.'])
    atomic(completed, result, immutable=True)
    atomic(OUT / 'status.json', dict(phase='completed_requires_independent_download_verification', assessment_sha256=sha(completed)))
    print('INPUT_VIEW_EXTERNAL_ASSESSMENT_COMPLETED', sha(completed), flush=True)
