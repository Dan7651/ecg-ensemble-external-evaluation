"""Five fixed input-view ResNet forward passes; reuse old scores, never train."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']: os.environ[key] = '1'
import fcntl
import platform
import sys
from input_view_followup_common import *

def batches_predict(model, x, torch):
    outputs = []
    with torch.inference_mode():
        for i in range(0, len(x), 128):
            with torch.autocast('cuda', dtype=torch.float16):
                logits = model(torch.from_numpy(np.asarray(x[i:i+128], dtype=np.float32)).cuda())
            outputs.append(logits.float().sigmoid().cpu().numpy())
    return np.concatenate(outputs)

def main():
    if sys.flags.optimize: raise RuntimeError('Integrity guards must remain enabled')
    held = open('/content/sph_input_view_control_v1.lock', 'a+')
    fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
    plan, fitlock = verify_fits()
    receipt = FITS / 'input_view_persistence_verified_v1.json'
    p = read(receipt)
    assert p['plan_sha256'] == sha(HERE / 'EVALUATION_PLAN.json')
    assert p['source_sha256'] == sha(HERE / 'persistence.py')
    assert all(p[k] for k in ['all_five_complete_before_flush', 'flush_and_unmount_completed',
                              'remount_completed', 'all_pinned_files_verified_after_remount'])
    assert sha(OLD / 'prediction_manifest.json') == plan['original_a01_prediction_manifest_sha256']
    assert sha(OLD / 'inference_lock.json') == plan['original_a01_inference_lock_sha256']
    assert sha(SPH / 'preparation_manifest.json') == plan['sph_preparation_manifest_sha256']
    assert sha(SPH / 'sph_primary_code_map.json') == plan['sph_primary_map_sha256']
    preparation = read(SPH / 'preparation_manifest.json')
    original = read(OLD / 'prediction_manifest.json')
    assert len(preparation['parts']) == len(original['parts']) == 83
    import torch, scipy, sklearn
    assert torch.cuda.is_available() and 'T4' in torch.cuda.get_device_name(0)
    torch.set_num_threads(2); torch.backends.cudnn.benchmark = False; torch.use_deterministic_algorithms(True)
    actual = dict(python=platform.python_version(), torch=torch.__version__, cuda=torch.version.cuda,
                  cudnn=torch.backends.cudnn.version(), numpy=np.__version__, scipy=scipy.__version__,
                  sklearn=sklearn.__version__, gpu=torch.cuda.get_device_name(0), deterministic=True)
    assert actual == read(FITS / 'environment.json'), 'Changed fitting environment: stop for review'
    import input_view_control as source
    assert sha(HERE / 'input_view_control.py') == '5b2e9365e25c27a9245fdeb8313ae73ede2bd811a8cef6344bc27050335bd1b0'
    models = []
    for seed in SEEDS:
        folder = FITS / 'resnet' / f'seed{seed}'
        saved = torch.load(folder / 'best_model.pth', map_location='cpu', weights_only=True)
        assert saved['selected_epoch'] == read(folder / 'endpoint.json')['selected_epoch']
        model = source.build_model('resnet'); model.load_state_dict(saved['model'], strict=True)
        models.append(model.cuda().eval().requires_grad_(False)); del saved
    # Exact first fit-sized batch replay before any new cohort scores.
    meta = BASE / 'ECG_Diagnosis_Project/processed_cache/ptb-xl_amplitude_v1/labels_and_folds.npz'
    assert sha(meta) == '79f69a27dcfc4aab024a8154ed32966bf6d2d1dfa18773e2f1090350bad9d5d7'
    with np.load(meta, allow_pickle=False) as z:
        rows = np.flatnonzero((z['strat_fold'] == 8) & (z['y_standard'].sum(1) > 0))[:128]
        ids, patients, labels = [z[k][rows].copy() for k in ['ecg_id', 'patient_id', 'y_standard']]
    packed = Path('/content/sph_resnet_jepa_view_cache_v1/ecg_8lead_q1000_int32.npz')
    if not packed.exists(): packed = BASE / 'ECG_Diagnosis_Project/processed_cache/ptbxl_jepa_250hz_v1/ecg_8lead_q1000_int32.npz'
    assert sha(packed) == '5bc139bcc9b50cd5fa8bb97164441d084d1fade200cd8ae886aebb26ead5bf79'
    with np.load(packed, allow_pickle=False) as z: x = z['signal_q_mv'][rows].astype(np.float32) / 1000.0
    for seed, model in zip(SEEDS, models):
        with np.load(FITS / 'resnet' / f'seed{seed}' / 'development_predictions.npz', allow_pickle=False) as z:
            assert all(np.array_equal(z[k][:128], a) for k, a in zip(['ecg_id', 'patient_id', 'y_true'], [ids, patients, labels]))
            assert np.array_equal(batches_predict(model, x, torch), z['y_prob'][:128]), 'Source batch exact replay failed'
    del x
    OUT.mkdir(exist_ok=True)
    code = read(HERE / 'bundle_manifest.json')['files']
    lock = dict(plan_sha256=sha(HERE / 'EVALUATION_PLAN.json'), code_sha256=code,
                fit_lock_sha256=sha(FITS / 'all_five_fits_locked.json'), persistence_sha256=sha(receipt),
                environment=actual, all_five_first128_development_exact_replay=True,
                all_five_source_replays_completed_before_new_control_inference=True)
    atomic(OUT / 'inference_lock.json', lock, immutable=True); lock_sha = sha(OUT / 'inference_lock.json')
    dest = OUT / 'prediction_chunks'; dest.mkdir(exist_ok=True)
    parts = []; total = 0
    for prepared, old in zip(preparation['parts'], original['parts']):
        assert prepared['filename'] == old['filename']
        target = dest / prepared['filename']; side = target.with_suffix('.json')
        value = chunk_read(target, side, lock_sha)
        if value is None:
            path = SPH / 'prepared_chunks' / prepared['filename']
            assert sha(path) == prepared['sha256']
            oldpath = OLD / 'prediction_chunks' / old['filename']; assert sha(oldpath) == old['sha256']
            with np.load(path, allow_pickle=False) as z, np.load(oldpath, allow_pickle=False) as o:
                assert z['ids'].tolist() == prepared['ids']
                assert all(np.array_equal(z[k], o[k]) for k in ['ids', 'patient_id', 'y'])
                assert z['x_jepa'].dtype == np.float32 and z['x_jepa'].shape == (len(z['ids']), 8, 2500)
                scores = np.stack([batches_predict(m, z['x_jepa'], torch) for m in models])
                assert scores.shape == (5, len(z['ids']), 5) and np.isfinite(scores).all()
                value = dict(ids=z['ids'], patient_id=z['patient_id'], y=z['y'], view_resnet=scores,
                             original_resnet=o['resnet'], jepa=o['jepa'], inference_lock_sha256=np.array(lock_sha))
                atomic(target, value, binary=True)
            atomic(side, dict(inference_lock_sha256=lock_sha, sha256=sha(target)), immutable=True)
        assert value['ids'].tolist() == prepared['ids']
        total += len(value['ids']); parts.append(dict(filename=target.name, sha256=sha(target), inference_lock_sha256=lock_sha))
        atomic(OUT / 'status.json', dict(phase='fixed_inference', completed_records=total, planned_records=21183))
        print('INPUT_VIEW_LOCKED_SPH_RECORDS', total, 21183, flush=True)
    assert total == 21183
    atomic(OUT / 'prediction_manifest.json', dict(parts=parts, records=total, inference_lock_sha256=lock_sha), immutable=True)
    del models; torch.cuda.empty_cache()
    from statistics_runtime import run_statistics
    run_statistics()

if __name__ == '__main__': main()
