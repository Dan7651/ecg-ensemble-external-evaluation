"""Actual flush/unmount/remount verification; called in the notebook kernel."""
import fcntl
from datetime import datetime, timezone
from input_view_followup_common import HERE, FITS, OUT, Path, read, sha, atomic, verify_fits

def verify_remount():
    plan_sha = sha(HERE / 'EVALUATION_PLAN.json')
    receipt = FITS / 'input_view_persistence_verified_v1.json'
    held = open('/content/sph_input_view_control_v1.lock', 'a+')
    fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        if receipt.exists():
            r = read(receipt)
            assert r['plan_sha256'] == plan_sha and r['source_sha256'] == sha(__file__)
            assert all(r[k] for k in ['all_five_complete_before_flush', 'flush_and_unmount_completed',
                                      'remount_completed', 'all_pinned_files_verified_after_remount'])
            verify_fits()
            print('INPUT_VIEW_EXISTING_PERSISTENCE_RECEIPT_VERIFIED', flush=True)
            return
        progress_path = Path('/content/sph_input_view_remount_progress_v1.json')
        p = read(progress_path) if progress_path.exists() else None
        if p: assert p['plan_sha256'] == plan_sha and p['source_sha256'] == sha(__file__)
        from google.colab import drive
        if not p or not p['flush_and_unmount_completed']:
            verify_fits()
            p = dict(plan_sha256=plan_sha, source_sha256=sha(__file__), all_five_complete_before_flush=True,
                     flush_and_unmount_completed=False, remount_completed=False,
                     all_pinned_files_verified_after_remount=False)
            atomic(progress_path, p)
            drive.flush_and_unmount()
            p['flush_and_unmount_completed'] = True; atomic(progress_path, p)
        drive.mount('/content/drive')
        p['remount_completed'] = True; atomic(progress_path, p)
        verify_fits()
        p.update(all_pinned_files_verified_after_remount=True,
                 files=read(HERE / 'expected_files.json'), verified_utc=datetime.now(timezone.utc).isoformat(),
                 no_fit_endpoint_or_checkpoint_modified=True)
        atomic(progress_path, p); atomic(receipt, p, immutable=True)
        print('INPUT_VIEW_ALL_FIVE_PERSISTED_AFTER_ACTUAL_REMOUNT', sha(receipt), flush=True)
    finally:
        held.close()
