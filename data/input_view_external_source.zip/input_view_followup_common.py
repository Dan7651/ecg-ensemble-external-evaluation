"""Input-view follow-up helpers; import performs no study reads or execution."""
from pathlib import Path
import hashlib
import json
import os
import numpy as np

HERE = Path(__file__).resolve().parent
BASE = Path('/content/drive/MyDrive')
RESULTS = BASE / 'ECG_Project_Final_Results'
FITS = RESULTS / 'sph_resnet_jepa_view_five_seed_20261028_v1'
OLD = RESULTS / 'sph_matched_seed_controls_20261027_v1/locked_sph_evaluation_v1'
SPH = RESULTS / 'sph_external_v1'
OUT = FITS / 'locked_sph_input_view_evaluation_v1'
SEEDS = [101, 202, 303, 404, 505]

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_text())

def atomic(path, value, binary=False, immutable=False):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    raw = None if binary else (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
    if immutable and path.exists():
        if binary or path.read_bytes() != raw: raise RuntimeError('Immutable file differs: ' + str(path))
        return
    tmp = path.with_name(path.name + '.partial')
    with tmp.open('wb') as f:
        if binary: np.savez_compressed(f, **value)
        else: f.write(raw)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)

def verify_files(root, expected):
    for name, digest in expected.items():
        if sha(root / name) != digest: raise RuntimeError('Frozen artifact mismatch: ' + name)

def verify_fits():
    plan = read(HERE / 'EVALUATION_PLAN.json')
    assert plan['fit_files_sha256'] == sha(HERE / 'expected_files.json')
    verify_files(FITS, read(HERE / 'expected_files.json'))
    locked = read(FITS / 'all_five_fits_locked.json')
    assert [e['seed'] for e in locked['endpoints']] == SEEDS and locked['no_external_inference']
    assert locked['global_protocol_sha256'] == sha(FITS / 'training_protocol.json')
    amendment = sha(FITS / 'amp_gradient_replay_amendment_v1.json')
    assert locked['execution_amendment_sha256'] == amendment
    for e in locked['endpoints']:
        folder = FITS / 'resnet' / f"seed{e['seed']}"
        # The recovery writer stamps each endpoint file and the aggregate lock's
        # TOP LEVEL. Its in-memory nested endpoints predate that added field.
        # Require the exact sidecar plus all shared fields, never rewrite either.
        endpoint = read(folder / 'endpoint.json')
        assert endpoint['execution_amendment_sha256'] == amendment
        assert e == {k: v for k, v in endpoint.items() if k != 'execution_amendment_sha256'}
        assert e['protocol_sha256'] == sha(folder / 'protocol.json')
        assert e['checkpoint_sha256'] == sha(folder / 'best_model.pth')
        assert e['prediction_sha256'] == sha(folder / 'development_predictions.npz')
        assert e['exact_fresh_saved_best_replay'] and e['no_external_inference'] and e['no_fold9_or_10_prediction']
    return plan, locked

def chunk_read(path, side, lock_sha):
    """Recover a completed NPZ if interrupted only before its redundant receipt."""
    if not path.exists(): return None
    with np.load(path, allow_pickle=False) as z:
        value = {k: z[k].copy() for k in z.files}
    assert str(value['inference_lock_sha256']) == lock_sha
    assert value['view_resnet'].shape == (5, len(value['ids']), 5)
    assert np.isfinite(value['view_resnet']).all()
    if side.exists():
        r = read(side); assert r['inference_lock_sha256'] == lock_sha and r['sha256'] == sha(path)
    else:
        atomic(side, dict(inference_lock_sha256=lock_sha, sha256=sha(path)), immutable=True)
    return value

def save_bootstrap(folder, draws, meta):
    path = folder / f"bootstrap_{(meta['completed']//50)%2}.npz"
    atomic(path, dict(draws=draws, metadata=np.frombuffer(json.dumps(meta).encode(), dtype=np.uint8)), binary=True)
    atomic(path.with_suffix('.json'), dict(sha256=sha(path), completed=meta['completed']))

def recover_bootstrap(folder, lock_sha):
    candidates = []
    for slot in [0, 1]:
        path = folder / f'bootstrap_{slot}.npz'; side = path.with_suffix('.json')
        if not (path.exists() and side.exists()): continue
        receipt = read(side)
        if sha(path) != receipt['sha256']: continue
        with np.load(path, allow_pickle=False) as z:
            meta = json.loads(z['metadata'].tobytes()); chunk = z['draws'].copy()
        assert meta['inference_lock_sha256'] == lock_sha and meta['completed'] == len(chunk) == receipt['completed']
        candidates.append((meta, chunk))
    if candidates: return max(candidates, key=lambda pair: pair[0]['completed'])
    if list(folder.glob('bootstrap_*.npz')): raise RuntimeError('No intact bootstrap generation; preserve evidence')
    return None
