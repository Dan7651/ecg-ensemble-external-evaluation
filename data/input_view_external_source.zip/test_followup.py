"""Bounded synthetic guards only; no real waveforms/checkpoints or GPU."""
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import numpy as np
import input_view_followup_common as common
import persistence
import statistics_runtime as stats

class Guards(unittest.TestCase):
    def test_bootstrap_resume_restores_identical_future_patient_draws(self):
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder); rng=np.random.default_rng(35)
            first=rng.integers(10,size=(50,10))
            common.save_bootstrap(folder,first,dict(completed=50,inference_lock_sha256='fixed',rng=rng.bit_generator.state))
            expected=rng.integers(10,size=(50,10))
            meta,past=common.recover_bootstrap(folder,'fixed')
            resumed=np.random.default_rng();resumed.bit_generator.state=meta['rng']
            np.testing.assert_array_equal(past,first)
            np.testing.assert_array_equal(resumed.integers(10,size=(50,10)),expected)
            with self.assertRaises(AssertionError):common.recover_bootstrap(folder,'different')

    def test_pair_indices_and_better_component_brier_direction(self):
        d = stats.definitions()
        self.assertEqual(d[0], ('original_RR',0,1,0,1))
        self.assertEqual(d[5], ('JJ',0,1,10,11))
        self.assertEqual(d[10], ('original_RJ',0,1,0,11))
        self.assertEqual(d[15], ('view_RR',0,1,5,6))
        self.assertEqual(d[24], ('view_RJ',4,0,9,10))
        p = np.ones((40,4)); p[:15,3] = .2; p[15:,3] = .1
        np.testing.assert_array_equal(stats.gains(p)[:,:,3], np.full((5,5),.1))
        np.testing.assert_array_equal(stats.contrasts(p), np.zeros((4,4)))

    def test_weighted_metrics_and_literal_patient_expansion_with_ties(self):
        rng = np.random.default_rng(18)
        y = rng.integers(0,2,(30,5),dtype=np.uint8)
        p = rng.integers(1,9,(30,5)).astype(np.float32)/10
        inv = np.repeat(np.arange(10),3); multiplicity = np.array([2,0,1,3,0,1,0,2,0,1])
        w = multiplicity[inv]; take = np.repeat(np.arange(30),w)
        got = stats.ScoreStatistics(y,p).evaluate(w)['macro'][stats.COLS]
        np.testing.assert_allclose(got, stats.reference(y[take],p[take]), atol=1e-12,rtol=0)
        np.testing.assert_allclose(got, stats.reference(y,p,w), atol=1e-12,rtol=0)

    def test_completed_chunk_recovery_and_corruption_refusal(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'chunk.npz'; side = path.with_suffix('.json')
            value = dict(ids=np.arange(2), view_resnet=np.full((5,2,5),.4,np.float32), inference_lock_sha256=np.array('locked'))
            common.atomic(path,value,binary=True)
            common.chunk_read(path,side,'locked'); self.assertTrue(side.exists())
            with self.assertRaises(AssertionError): common.chunk_read(path,side,'other')
            common.atomic(path,dict(value,view_resnet=np.full((5,2,5),.3,np.float32)),binary=True)
            with self.assertRaises(AssertionError): common.chunk_read(path,side,'locked')

    def test_persistence_requires_real_operation_success_and_post_mount_check(self):
        with tempfile.TemporaryDirectory() as folder:
            temp = Path(folder); events = []
            def verify(): events.append('verified')
            drive = types.SimpleNamespace(flush_and_unmount=lambda:events.append('flush'), mount=lambda _:events.append('mount'))
            # Redirect only the runtime-local journal/lock paths used by this function.
            original_path = Path
            def local_path(name):
                return temp/Path(name).name if str(name).startswith('/content/') else original_path(name)
            fake_colab = types.ModuleType('google.colab'); fake_colab.drive=drive
            with patch.object(persistence,'FITS',temp), patch.object(persistence,'Path',local_path), patch.object(persistence,'verify_fits',verify), patch('builtins.open',side_effect=lambda name,*a,**kw: open_original(temp/Path(name).name,*a,**kw) if str(name).startswith('/content/') else open_original(name,*a,**kw)), patch.dict(sys.modules,{'google.colab':fake_colab}):
                persistence.verify_remount()
            self.assertEqual(events,['verified','flush','mount','verified'])
            r=json.loads((temp/'input_view_persistence_verified_v1.json').read_text())
            self.assertTrue(r['all_pinned_files_verified_after_remount'])
            (temp/'input_view_persistence_verified_v1.json').unlink()
            (temp/'sph_input_view_remount_progress_v1.json').unlink()
            def bad_mount(_): raise RuntimeError('Synthetic connection failure')
            drive.mount=bad_mount
            with patch.object(persistence,'FITS',temp), patch.object(persistence,'Path',local_path), patch.object(persistence,'verify_fits',verify), patch('builtins.open',side_effect=lambda name,*a,**kw: open_original(temp/Path(name).name,*a,**kw) if str(name).startswith('/content/') else open_original(name,*a,**kw)), patch.dict(sys.modules,{'google.colab':fake_colab}):
                with self.assertRaises(RuntimeError): persistence.verify_remount()
            self.assertFalse((temp/'input_view_persistence_verified_v1.json').exists())

open_original = open
if __name__ == '__main__': unittest.main()
