# Deposited-plan extension: status and execution order

**Phase 1 preparation only. Not deposited; no new scientific outcome has been computed.**

1. `PROTOCOL.md` fixes all new analyses, five seeds per family, pairing, thresholds, windowing and decision gate.
2. `analysis_core.py` implements the statistical rules without loading study data. `test_analysis_core.py` uses only synthetic examples.
3. `bundle_manifest.json` authenticates the exact deposit ZIP and included files.
4. Publish `protocol_bundle.zip` as a versioned public Zenodo record (or use an independently verified OSF registration with a separately reviewed gate adapter). A saved draft/reserved DOI is insufficient.
5. Verify the real published record with `python deposit_gate.py --record-id ACTUAL_RECORD_ID`. This authenticates downloaded public bytes. Never create a receipt by hand.
6. Only after that gate: finish/verify the matched-fit and missing-record inference launchers, then execute on the existing Colab T4. Current preparation does not assert these runners are already complete or connected.
7. Download actual outputs, independently verify, run the frozen framing decision, and only then rewrite the paper.

## Bounded checks already executable

From this directory, in an isolated scientific environment:

```sh
python -m unittest test_analysis_core -v
python -m unittest test_deposit_gate -v
```

These are synthetic/data-free checks, not experiment results. No browser or GPU monitoring has been scheduled. The old manuscript, old predictions and original checkpoints are preserved.

## Publication dependency

The connected GitHub account is `Dan7651`; the connector returned no accessible repository. No repository was created or assumed. Chrome had no signed-in Zenodo session. The Zenodo login page has been left open for the account owner. A real creator identity and author list must be grounded in the account/author information before public deposition; the GitHub display name was empty. No account credentials are requested in chat.

## Intended public release

Code, synthetic fixtures, environment specification, aggregate outputs, source/weight hashes and per-table/per-figure commands. Exclude raw ECGs, patient identifiers, private per-record predictions, credentials, copied publisher pages and unlicensed pretrained weights. A local ZIP is not public code and has no DOI. The later software DOI is distinct from this prospective protocol record.

## Scientific scope

Prospectively specified extensions of a previously observed population do not repair the historical lack of an untouched confirmatory cohort. The planned control study tests whether this particular fusion gain exceeds matched two-model controls; it cannot isolate supervision paradigm from architecture/pretraining. A negative result is preserved and changes the framing, not the protocol.
