"""Build a data-free deposit bundle; does not create an external timestamp."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
FILES = ['PROTOCOL.md', 'analysis_registry.json', 'analysis_core.py', 'test_analysis_core.py',
         'deposit_gate.py', 'test_deposit_gate.py', 'requirements-analysis.txt',
         'source_recipe_pins.json', 'JBHI_INSTRUCTIONS_CHECK.md', 'POST_CONTROL_MANUSCRIPT_PLAN.md',
         'README.md', 'seal_phase1.py']


def main():
    if (ROOT / 'deposit_receipt.json').exists():
        raise RuntimeError('A deposited protocol cannot be silently resealed')
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in FILES}
    out = ROOT / 'protocol_bundle.zip'
    # Stable ZIP metadata; no usernames, absolute paths, credentials or datasets.
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name in FILES:
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 27, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, (ROOT / name).read_bytes())
    manifest = dict(state='SEALED_LOCALLY_NOT_INDEPENDENTLY_DEPOSITED',
                    prepared_utc=datetime.now(timezone.utc).isoformat(),
                    local_zip_date_is_not_independent_evidence=True,
                    files=hashes, bytes=out.stat().st_size,
                    bundle_sha256=hashlib.sha256(out.read_bytes()).hexdigest())
    (ROOT / 'bundle_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({k: v for k, v in manifest.items() if k != 'files'}, indent=2))


if __name__ == '__main__': main()
