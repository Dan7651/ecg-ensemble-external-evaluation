"""Verify a PUBLIC Zenodo version and its exact bundle before outcome access.

No token or credential is used. A local date/receipt alone never opens the gate.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import urlparse
import zipfile

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def public_get(url):
    u = urlparse(url)
    if u.scheme != 'https' or u.hostname != 'zenodo.org' or u.username or u.password:
        raise ValueError('Only public HTTPS Zenodo URLs are allowed')
    return subprocess.check_output(['curl', '--silent', '--show-error', '--fail', '--location',
                                    '--proto', '=https', '--max-time', '90', url])


def verify_record(record_id, root=ROOT, fetch=public_get):
    record_id = str(record_id)
    if not re.fullmatch(r'[0-9]+', record_id):
        raise ValueError('A published numeric record ID is required')
    root = Path(root)
    manifest = json.loads((root / 'bundle_manifest.json').read_text())
    local = (root / 'protocol_bundle.zip').read_bytes()
    if sha(local) != manifest['bundle_sha256']:
        raise ValueError('Local bundle changed after sealing')
    with zipfile.ZipFile(io.BytesIO(local)) as z:
        for name, expected in manifest['files'].items():
            if sha(z.read(name)) != expected or sha((root / name).read_bytes()) != expected:
                raise ValueError(f'Deposited source/protocol drift: {name}')
    api = f'https://zenodo.org/api/records/{record_id}'
    response = fetch(api)
    record = json.loads(response)
    if str(record.get('id')) != record_id:
        raise ValueError('Record ID mismatch')
    if not (record.get('submitted') is True or record.get('is_published') is True or record.get('status') == 'published'):
        raise ValueError('An unpublished draft or reserved DOI is insufficient')
    doi = record.get('doi') or record.get('pids', {}).get('doi', {}).get('identifier') or record.get('metadata', {}).get('doi')
    if not doi or not doi.startswith('10.5281/zenodo.'):
        raise ValueError('No registered Zenodo DOI in public record')
    files = record.get('files', [])
    if isinstance(files, dict):
        files = list(files.get('entries', {}).values())
    matches = [v for v in files if v.get('key') == 'protocol_bundle.zip']
    if len(matches) != 1:
        raise ValueError('Public record must expose the exact protocol bundle')
    info = matches[0]
    link = info.get('links', {}).get('content') or info.get('links', {}).get('self')
    if not link or '/draft' in link:
        raise ValueError('Missing public file URL')
    remote = fetch(link)
    if sha(remote) != manifest['bundle_sha256']:
        raise ValueError('Published bytes differ from the sealed protocol bundle')
    checksum = info.get('checksum', '')
    if checksum.startswith('md5:') and hashlib.md5(remote).hexdigest() != checksum[4:]:
        raise ValueError('Provider checksum mismatch')
    if checksum.startswith('sha256:') and sha(remote) != checksum[7:]:
        raise ValueError('Provider checksum mismatch')
    if not record.get('created') or not record.get('updated', record.get('modified')):
        raise ValueError('Independent provider timestamps absent')
    return dict(gate_passed=True, provider='Zenodo', record_id=record_id, doi=doi,
                public_url=f'https://zenodo.org/records/{record_id}',
                provider_created_utc=record['created'], provider_updated_utc=record.get('updated', record.get('modified')),
                observed_utc=datetime.now(timezone.utc).isoformat(),
                public_response_sha256=sha(response), bundle_sha256=sha(remote),
                protocol_sha256=manifest['files']['PROTOCOL.md'],
                historical_outcomes_already_known=True, fresh_cohort_confirmation=False), response


def require_verified_deposit(root=ROOT):
    root = Path(root)
    path = root / 'deposit_receipt.json'
    if not path.exists():
        raise RuntimeError('STOP: no verified independent deposit; no new study outcome access permitted')
    old = json.loads(path.read_text())
    if old.get('gate_passed') is not True:
        raise RuntimeError('STOP: deposit gate is not passed')
    live, _ = verify_record(old['record_id'], root)
    for field in ['record_id', 'doi', 'bundle_sha256', 'protocol_sha256']:
        if live[field] != old[field]:
            raise RuntimeError(f'STOP: changed deposited artifact {field}')
    # Public update time must be no later than the original observed gate. A
    # later metadata/file edit requires review; do not silently admit a revision.
    def dt(value): return datetime.fromisoformat(value.replace('Z', '+00:00'))
    if dt(live['provider_updated_utc']) > dt(old['observed_utc']):
        raise RuntimeError('STOP: public record changed after original verification')
    return live


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--record-id', required=True)
    args = parser.parse_args()
    if (ROOT / 'deposit_receipt.json').exists():
        raise RuntimeError('Existing receipt is immutable; preserve it before an explicit amendment')
    receipt, response = verify_record(args.record_id)
    (ROOT / 'public_deposit_response.json').write_bytes(response)
    (ROOT / 'deposit_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
