# Matched-seed ensemble controls and transport diagnostics for ECG external evaluation

Version 1.0 — prepared 27 October 2026. **Not yet deposited or registered.**

## 1. Timing, scope and prior knowledge

This document prospectively specifies NEW analyses in an existing, extensively explored research project. It does not preregister the original SPH study retrospectively, create an untouched test set, establish clinical label equivalence, or make a new architecture claim. No new analysis listed below may run until a publicly retrievable, independently dated deposit of this exact protocol and its analysis registry has been verified. A local date, local checksum, reserved DOI or unpublished draft does not satisfy the gate. The deposit receipt must identify the published version, UTC timestamp, DOI/URL, exact downloaded file SHA-256 and the analysis-bundle SHA-256. Later changes require a dated amendment, preserving the original, and must identify whether outcomes were already inspected.

Already known: for the original seed-42 pair on 21,183 selected SPH ECGs, ResNet/JEPA/equal blend macro AUROC is 0.9348391383/0.9404413292/0.9449300923. Blend-minus-JEPA is 0.0044887631, with a post hoc patient-bootstrap interval [0.002897346, 0.006289329]. The development threshold vector lowered macro F1 relative to 0.5. Component results, mapping sensitivity, calibration, age/sex/duration subgroups, earliest-record sensitivity and alternative descriptive blends have already been viewed. Their old plans have only internal timestamps. Results from unrelated Founder/S4 seed studies are not matched controls for these models. All PTB-XL folds and previous external results have historical exposure. New inference is a preplanned extension on an observed cohort, not independent cohort confirmation.

## 2. Questions and complete analysis inventory

* A01: five independent ResNet fits and five independently initialized JEPA nonlinear heads; matched same-family and mixed-family two-model controls.
* A02: original frozen pair on the 4,587 previously excluded SPH ECGs; all-25,770 inclusion sensitivity with mapped-negative labels.
* A03: external-oracle F1 thresholds, patient-cross-fitted thresholds and the unchanged transported development vector.
* A04: explicitly retrospective prevalence-adjusted thresholds, and sensitivity at fixed specificity 0.90, 0.95 and 0.99.
* A05: calibration offset versus prior-shift prediction, joint intercept/slope, and paired Brier differences.
* A06: complete-waveform window aggregation for the 5,442 eligible SPH recordings longer than 10 seconds.
* A07: public source/environment release, checkpoint and artifact hashes, one command per table/figure, reference verification, and a result-dependent framing decision.

No additional cohort, new encoder, fine-tuned encoder, augmentation search, model/loss/threshold sweep or best-seed ensemble is included. Those would require a separate future protocol. Original failed branches stay closed.

## 3. Data and immutable original model anchors

The five outputs, in order, are NORM, MI, STTC, CD and HYP. Training uses positive-superclass PTB-XL records in folds 1–7; development selection uses positive-superclass records in fold 8. There are 14,955 training and 2,129 development records (17,084 total); exact metadata, IDs, patients, labels and cache hashes must be checked before fitting. No fold 9/10 prediction or model selection is planned. Patient identities must not cross fitting/development partitions.

The original selected SPH population contains 21,183 ECGs from 20,401 patients; all-public-record sensitivity contains 25,770 ECGs. Existing mapping SHA-256: `cfa4b658400c94bab5e1a0635b9d287d36e70648bb96463278d4ee4d94d9e1d1`. NORM requires explicit code 1. The map is unchanged. Records without any mapped target are all-zero mapped-annotation rows, **not asserted clinically normal or disease-free**. They may have unrepresented disease. No expert adjudication is invented.

Frozen original anchors:

| Artifact | SHA-256 |
|---|---|
| ResNet weights | `fd83f0be7ab01b3ba2445aa1c9582800222d300c3088e96c154711724fdc10c5` |
| JEPA nonlinear head | `2b4eab786f806df1a3fba6ba769931b869520cf04982bcf00bd6e04c59717de7` |
| JEPA encoder | `61334869f905a7d6de32bc573c60024eaf6efba7c35c0e45fc2ea7d52b6ff66e` |
| ResNet normalization | `df29c0173c2f89208a7d6cd5f594ad85da6bdf6663edb8cbd8408334ee4493af` |

Original encoder source commit: `d937ad2c2c8a1e22856ce7e4a23a30f84a71217c`. Original per-record predictions and analysis files remain untouched. The existing labels, outcomes and exact-match overlap audit do not establish comprehensive pretraining nonoverlap.

## 4. A01 — matched-seed training and controls

### 4.1 Fixed fits, hardware and selection

Use exactly five NEW seeds, in this order: **101, 202, 303, 404, 505**, for each family. Do not replace a failed or weak seed. Do not count the already selected seed-42 fit among these five. Report every seed, failed fit and actual runtime. Preserve seed-42 models only as historical anchors and for A02–A06.

ResNet: the original `OriginalResNet` architecture (six residual blocks; mean/max temporal pooling; 512→256→5 head; dropout 0.3), 12-lead filtered physical-mV 100-Hz, 1,000-sample cache, per-lead mean/std fitted only on the fitting rows. Unweighted BCEWithLogits, batch 64, AdamW learning rate 0.001/weight decay 0.01, cosine schedule over 20 epochs to 0.00001, AMP with gradient norm cap 1, maximum 20 epochs/patience 6. A checkpoint replaces the best only if development AUROC exceeds the stored best by more than 0.0001, matching the original selection convention. Development batch 128, fixed row order; final stored probabilities use FP32 sigmoid of the original AMP forward. Retain optimizer, scheduler, scaler and all RNG states.

JEPA: one unchanged, frozen public encoder and its existing 768-dimensional feature cache, same eight-lead/input transform as the original feature extraction. Authenticate feature IDs and extraction provenance. Fit StandardScaler on training features only. The 768→128→5 nonlinear head uses GELU/dropout 0.5. Unweighted BCEWithLogits, batch 256, AdamW learning rate 0.0003/weight decay 0.01, FP32, maximum 40 epochs/patience 8; improvement greater than 0.000001, matching the original. Only head initialization, shuffle and dropout vary by seed; the encoder does not. JJ controls consequently test head-seed diversity, not independent encoder pretraining. This distinction must accompany the control result.

For new fits, disable cuDNN benchmarking and enable deterministic algorithms where supported. Pin and record the actual T4 environment before fitting; an unsupported deterministic operation is a preflight failure requiring an explicit, dated implementation amendment, not silent fallback. This is a new controlled replication of the recipes; it is not a promise of bitwise seed-42 reproduction in a different software stack.

Before expensive fitting: check source/metadata/cache integrity, shapes, finite synthetic losses/gradients, exact model/optimizer/scaler/all-RNG continuation using disposable steps, selection tie logic and absence of patient overlap. Real-data capacity uses training records only: <=14 GiB peak and <=15 minutes per ResNet training epoch. Discard probe updates and reseed. No scientific training starts until the deposit gate passes. Recoverable technical fixes may not change this recipe; preserve error, source and amendment receipts. Never rerun completed epochs or raw preprocessing. Use the existing preauthorized T4, one fit at a time; no paid infrastructure. Pause for actual resource exhaustion, not a poor score.

### 4.2 Locked evaluation and equal-size controls

Finish all ten fits and lock every selected checkpoint before inspecting new SPH scores. Reuse existing 10-second SPH preprocessing and frozen encoder features if their provenance/IDs match; only missing deterministic cache entries may be prepared. No external labels select epoch, seed, weight or threshold. Evaluate all ten singles on exactly the original 21,183 rows.

Every ensemble is an equal probability average of exactly two models. Index the five seeds 0…4; i+1 wraps modulo five. The five primary blocks are:

* RR_i = (R_i + R_(i+1))/2;
* JJ_i = (J_i + J_(i+1))/2;
* RJ_i = (R_i + J_(i+1))/2.

For each metric M and each ensemble E with components a,b, gain is M(E) − max(M(a),M(b)). AUROC is primary; AP and F1 at 0.5 are secondary; Brier uses min(component Brier) − ensemble Brier so a positive value consistently indicates improvement. Report every component/ensemble endpoint and gain; mean, sample SD (ddof=1), minimum and maximum across the five blocks. Blocks reuse fitted models and are dependent; SD/range are descriptive training-seed variability, not five independent studies. For transparency also publish all 10 unordered RR, 10 unordered JJ and 25 RJ pair endpoints, with no best-pair selection. The extra pair rows are dependent sensitivity analyses, not 45 independent replications.

Primary family contrasts are mean gain(RJ) − mean gain(RR), and mean gain(RJ) − mean gain(JJ). Patient-cluster bootstrap below recomputes the better component within each draw. It measures patient-sampling uncertainty conditional on these fits, not independent training-seed uncertainty. Seed means/SD/ranges are reported separately; no spurious t interval treats overlapping blocks as independent.

### 4.3 Framing decision, fixed before new outcomes

Retain a cross-paradigm *empirical complementarity* framing only if both primary AUROC gain contrasts are positive, both Bonferroni-adjusted patient intervals have positive lower limits, at least four of five primary blocks have RJ gain larger than both RR and JJ gains, and mean RJ AP/F1 gains are not worse than either control. This is an operational framing rule, not proof that supervision paradigm caused the difference; architecture, pretraining and head-only training remain confounded.

If mean contrasts are nonpositive, frame as external validation of ensembling. Otherwise label the evidence mixed/seed-dependent and report the distribution without a cross-paradigm superiority claim. Never select another pairing or metric to rescue the decision. No result implies a matched published benchmark win or guarantees acceptance.

## 5. A02 — excluded-record sensitivity

Run only the original frozen seed-42 ResNet/head/encoder on the 4,587 missing rows, preserving their original IDs and patients. Reuse the original 21,183 predictions verbatim; do not rerun them. All-row sensitivity uses the identical map; zero mapped targets remain zero, including for NORM. Compare NORM AUROC, AP, sensitivity, specificity and FPR at 0.5 and the original NORM threshold 0.48 for all three original arms. Report selected-only, added-only and all-record denominators, number of patients, class counts, FPR numerator/denominator and paired all-minus-selected patient-bootstrap changes. Selected and added rows can share patients; cluster globally across all 25,770 rows. Never present added records as adjudicated healthy negatives. Report other four classes and macro metrics as secondary; do not remap ambiguous codes after viewing scores.

## 6. A03–A05 — threshold, prevalence and calibration diagnostics

Use original, unchanged seed-42 probabilities, initially on the original selected population. No diagnostics are applied to choose a new deployment model.

**A03:** report fixed 0.5 and the original development vector [0.48,0.37,0.42,0.43,0.20] for the blend. External-oracle thresholds maximize per-class F1 over unique external scores, plus no-positive/all-positive endpoints. Ties choose the threshold nearest 0.5, then the lower threshold. These thresholds are fitted and assessed on the same cohort: report them as optimistic, retrospective upper bounds, never independent transfer performance. Also use five patient-disjoint folds (sorted patient IDs shuffled by seed 2026102703; round-robin fold assignment), fitting thresholds on four folds and scoring the held-out fold. Aggregate held-out confusion counts; do not average fold F1. If a fitting fold lacks positives/negatives for a class, mark that class/analysis unavailable. Apply this identical scheme to all three original arms for the oracle/cross-fit comparison; only the blend has the transported vector.

**A04:** source prevalence is calculated from the existing 2,129 fold-8 development rows. External prevalence is the observed selected SPH prevalence: its use is explicitly retrospective. For each class, delta = logit(pi_external) − logit(pi_source). Label-shift-adjusted scores are sigmoid(logit(p)+delta); equivalently apply raw-score threshold sigmoid(logit(t_development)−delta). Report the adjustment as a prior-shift assumption sensitivity, not newly validated calibration or F1-optimal transfer. No raw probability is overwritten. Sensitivity at specificity 0.90/0.95/0.99 uses empirical ROC thresholds with conservative tie handling (specificity must meet the target), reported as external-oracle diagnostics; additionally compute the five-fold patient-cross-fitted version using thresholds fitted on four folds. All thresholds and achieved specificity are reported.

**A05:** fit a fixed-slope (slope=1) logistic calibration offset on each original arm and class, with p clipped to [1e-6,1−1e-6]. Compare observed external offset with (i) delta alone, the prediction for a source-calibrated classifier, and (ii) the observed source fixed-slope offset + delta. Report discrepancies and their patient intervals, resampling source and external patient sets independently. Joint free intercept/slope estimates are a separate descriptive model; its intercept is not directly equated to delta when slope differs from one. Failed/nonfinite fits are reported, never dropped silently.

Compute per-class and macro paired Brier differences for blend−JEPA and blend−ResNet with percentile patient intervals. Smaller is better; describe the observed estimate without claiming lower population Brier if the interval includes zero. Existing original draws can be reused if verified and exactly applicable; record their historical generation date. For newly generated uncertainty use the common draws below. Preserve the existing MI/HYP reliability curves and add an interpretation tied to their actual bin counts/intervals, rather than extrapolating sparse bins.

## 7. A06 — full-waveform inference without retraining

Use only the original selected pair on the 5,442 eligible records with N>5,000 samples at 500 Hz. For each recording, take full 5,000-sample windows starting 0, 5,000, 10,000, … while a complete window fits; append start N−5,000 if not already present. Thus the terminal context is retained, partial windows are not zero-padded and every sample is covered. Deduplicate start indices. The original first-window probabilities are reused exactly; each additional window receives the original per-arm 10-second preprocessing independently. Average probabilities equally across windows within each arm; then average arms equally. Do not average logits, vary stride or select a window from its score. This is fixed-window full-coverage aggregation, not passing arbitrary-length signals to a fixed-position encoder.

Report long-record-only and all-selected-cohort comparisons with original first-10-second predictions. For 15,741 exact-10-second records retain original probabilities. Publish duration/window-count distribution, runtime, per-class/macro AUROC/AP/F1/Brier and paired patient intervals. Window count and added compute are disclosed; this is additional inference context, not a free architecture gain. No inference on excluded long records is added to this analysis.

## 8. Uncertainty, missingness and computational provenance

New common patient bootstrap: 2,000 draws, NumPy PCG64 seed 2026102701, sampling patients with replacement and retaining all their records with frequency weights. Recompute full nonlinear metrics/threshold fits where relevant inside a draw; cross-fitted threshold analyses retain the preassigned patient folds and refit in the sampled training folds. No record bootstrap. For paired comparisons use the same patient counts for both arms/populations. Report valid counts for each metric; require at least 1,960 valid draws for a reported interval. Otherwise suppress that interval, explain the missing support, and retain the point estimate. No redrawing until a desired interval appears. Ordinary descriptive intervals use 2.5/97.5 percentiles; the two primary A01 contrasts use 1.25/98.75 percentiles (Bonferroni family coverage >=95%). No confirmatory p value is asserted on the previously viewed population. A05 source/external offset uncertainty uses independent patient resamples, seed 2026102705, with the same valid-draw rule.

Freeze code, environment, protocols, cache/IDs/labels/checkpoint/prediction hashes and exact fitting/selection histories. Align all arms by exact ECG/patient IDs, never row position alone. Verify finite [0,1] scores and identical labels; record precision and any warm replay tolerance. Independently recompute reported metrics from downloaded prediction bytes; recorded remote replay and local arithmetic verification are different evidence. Save incomplete failures, original artifacts and successful checkpoints. No private data, credential, ECG waveform or patient-level prediction is published with the code release. Authorized research computation may read existing deidentified data; public release contains code, synthetic fixtures, aggregate tables/figures and manifests only.

## 9. Publication and manuscript gate

Release a clean source repository on GitHub and archive a versioned release on Zenodo with a real DOI, environment specification, fixed seeds, checkpoint hashes and exact commands for each table/figure. A DOI reservation or local ZIP is not a release. Include third-party attribution/licenses; do not relicense vendor sources or distribute pretrained weights without their terms. Any missing access, creator identity or signing requirement is a genuine publication blocker, not justification for a fabricated DOI.

Only after A01 control verification make the framing decision and rewrite the manuscript. The main text must include ranking, calibration and transported-threshold failure together, lead with the gain over the stronger JEPA component, qualify the MI/HYP contribution, and give the code-147 sensitivity alongside fusion gain. Separate original locked, already-viewed post hoc and newly deposit-specified extension analyses in a table. Replace irrelevant imaging references with verified clinical-prediction/ECG guidance; verify article versions, not just plausible bibliography fields. Remove internal work-process headings from the paper, preserving genuine methodological limitations and missing declarations accurately in the appropriate locations. Do not claim a clinician has certified the mapping or authors have approved/signatured declarations unless that actually occurs.

Current JBHI source-page requirements and any conflicts/unverified details are recorded separately in `JBHI_INSTRUCTIONS_CHECK.md`. Submission, paid publication, author signatures, invented ethics approval and journal acceptance are outside this execution authorization.
