"""Synthetic publication fixtures: never contact a real repository."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from deposit_gate import verify_record, require_verified_deposit, sha


class DepositGate(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / 'PROTOCOL.md').write_text('Synthetic protocol; no research results.')
        with zipfile.ZipFile(self.root / 'protocol_bundle.zip', 'w') as z:
            z.write(self.root / 'PROTOCOL.md', 'PROTOCOL.md')
        self.blob = (self.root / 'protocol_bundle.zip').read_bytes()
        (self.root / 'bundle_manifest.json').write_text(json.dumps(dict(bundle_sha256=sha(self.blob), files={'PROTOCOL.md': sha((self.root / 'PROTOCOL.md').read_bytes())})))
        self.record = dict(id=999, status='published', doi='10.5281/zenodo.999', created='2026-01-01T00:00:00Z', updated='2026-01-01T00:00:01Z', files=[dict(key='protocol_bundle.zip', checksum='md5:' + hashlib.md5(self.blob).hexdigest(), links={'self': 'https://zenodo.org/api/records/999/files/protocol_bundle.zip/content'})])

    def tearDown(self): self.temp.cleanup()

    def fetch(self, url):
        return json.dumps(self.record).encode() if url.endswith('/999') else self.blob

    def test_public_record_and_exact_bytes_required(self):
        result, _ = verify_record(999, self.root, self.fetch)
        self.assertTrue(result['gate_passed'])
        self.assertFalse(result['fresh_cohort_confirmation'])

    def test_reserved_doi_unpublished_draft_does_not_pass(self):
        self.record['status'] = 'draft'
        with self.assertRaises(ValueError): verify_record(999, self.root, self.fetch)

    def test_public_file_mismatch_does_not_pass(self):
        self.blob += b'changed'
        with self.assertRaises(ValueError): verify_record(999, self.root, self.fetch)

    def test_local_source_change_does_not_pass(self):
        (self.root / 'PROTOCOL.md').write_text('Undeclared changed hypothesis')
        with self.assertRaises(ValueError): verify_record(999, self.root, self.fetch)

    def test_missing_receipt_prevents_any_live_request(self):
        with self.assertRaisesRegex(RuntimeError, 'no verified independent deposit'):
            require_verified_deposit(self.root)


if __name__ == '__main__': unittest.main()
