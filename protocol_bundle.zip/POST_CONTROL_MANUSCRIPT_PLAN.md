# Apply after the verified A01 result; not a manuscript rewrite

The present manuscript and original results are preserved. Do not change its title or abstract in anticipation of the new controls.

## Result-dependent framing

Use `analysis_core.framing_decision` with the deposited pair definitions and adjusted intervals. Report each of the five blocks and all single fits. “Cross-paradigm” can describe the evaluated pair, but a superiority claim depends on the control gate and must acknowledge architecture/pretraining confounding and shared-encoder JJ controls. Otherwise use an empirical ensemble external-validation title. None of the possible outcomes is automatically a new method or a published benchmark victory.

## Main paper changes

* Open the results with the gain over the stronger JEPA component, **+0.004488763 AUROC**, not the larger ResNet contrast. Keep both comparisons in a table.
* Put the failed threshold transfer beside discrimination in the abstract. Add A05 calibration findings only once verified. The old abstract's omission of negative results is not a suitable publication strategy.
* State that the 89.6% MI/HYP AP contribution is descriptive; HYP's interval includes zero, so evidence is primarily driven by MI. Do not imply two independently significant contributors.
* State that withdrawing code 147 changes blend AUROC from about 0.94493 to 0.93157: roughly **0.01336**, around three times the observed blend-over-JEPA gain. This is mapping sensitivity, not proof of a different clinical ground truth.
* Rename “Reviewer-Requested Descriptive Diagnostics” to “Descriptive Subgroup and Calibration Diagnostics.” Remove author workflow tasks from article prose. Keep real limitations, approvals and availability statements accurate.
* Main text must summarize the current supplement's component comparisons, mapping sensitivity and threshold/calibration findings (verify S2/S4/S7 labels against the final restructured supplement rather than assume numbering stays fixed).
* For “lowest Brier,” report the actual paired contrast and A05 interval; if its interval spans zero, use “lowest observed Brier estimate.”
* Explain MI reliability in light of its low prevalence and overprediction; explain HYP's sparse positives and wide bin uncertainty. These interpretations must reference occupied-bin counts and observed curves; they are not newly recalibrated predictions.

## Analysis-status table

| Group | Timing and interpretation |
|---|---|
| Original locked SPH transfer | Original frozen source/weights/map/threshold comparison; retain original provenance and limitations |
| Existing component, mapping, calibration and subgroup extensions | Post hoc on a viewed cohort; internal-date plans; not selection-adjusted |
| A01–A06 extension | Independently deposit-specified before these new outcomes only; existing cohort already known; not fresh cohort confirmation |
| Future untouched cohort | Not included or claimed in this phase |

## Relevant reference substitutions and evidence plan

Remove `claim2020` and `mehrtash2020` from the next manuscript version; check all uses before deleting bibliography entries. Replace their relevant reporting/calibration claims with clinical-prediction guidance, without replacing an imaging paper by a loosely related citation merely to maintain a reference count.

Candidates to retrieve and verify from primary sources:

1. TRIPOD+AI: DOI `10.1136/bmj-2023-078378`. Reporting clinical prediction models; not a certification of this model's clinical utility.
2. Perez Alday et al., *Classification of 12-lead ECGs: the PhysioNet/Computing in Cardiology Challenge 2020*, DOI `10.1088/1361-6579/abc960`, final journal article. Use for multicentre ECG heterogeneity, hidden-test performance and reproducibility. Distinguish it from the shorter CinC proceedings version.
3. Strodthoff et al., *Automatic 12-lead ECG Classification Using a Convolutional Network Ensemble*, DOI `10.22489/CinC.2020.130`. Use for ECG ensemble and variable-duration precedent; it does not prove a cross-paradigm advantage here.

The complete existing bibliography needs a row-by-row primary-source check: title, authors/order, publication/version/year, DOI/URL, and the specific sentence supported. Publisher metadata verification is not full-text verification. An AI-assisted source audit must not be described as human or clinician signoff. Do not remove an unresolved-verification caveat merely because the DOI resolves. For arXiv/medRxiv, cite the actual downloaded version; retain preprint status where applicable.

## JBHI layout and declarations

Use the actual selected `ieeecolor` original-research template after the gate. Abstract 150–250 words, one paragraph; no citations/abbreviations/equations. Restructure main plus supplement to the official stated combined 14-page ceiling. Do not accept a charge agreement or submit the paper without separate authority. Real author names/ORCIDs, funding, conflicts, consent signatures and institutional ethics position remain author facts, not generated assertions. Keep substantive AI assistance disclosed.
